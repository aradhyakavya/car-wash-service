document.addEventListener("DOMContentLoaded", function () {
    console.log("Car Wash Service Loaded");

    // Contact Form Submission
    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent page reload
            alert("Thank you for contacting us! Our team will get back to you soon.");
            contactForm.reset();
        });
    }

    // Registration Form Submission
    const registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent page reload

            let name = document.getElementById("regName").value;
            let mobile = document.getElementById("regMobile").value;
            let password = document.getElementById("regPassword").value;

            // Validate Mobile Number (10 Digits)
            if (mobile.length !== 10 || isNaN(mobile)) {
                alert("Please enter a valid 10-digit mobile number.");
                return;
            }

            // Validate Password (Minimum 6 Characters)
            if (password.length < 6) {
                alert("Password must be at least 6 characters.");
                return;
            }

            // Show Success Message
            let registerMessage = document.getElementById("registerMessage");
            if (registerMessage) {
                registerMessage.innerText = "Registration Successful! You can now log in.";
                registerMessage.style.color = "green";
            }

            registerForm.reset(); // Reset the form
        });
    }

    // Login Form Submission
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent page reload

            let mobile = document.getElementById("loginMobile").value;
            let password = document.getElementById("loginPassword").value;

            // Validate Mobile Number (10 Digits)
            if (mobile.length !== 10 || isNaN(mobile)) {
                alert("Please enter a valid 10-digit mobile number.");
                return;
            }

            // Validate Password (Minimum 6 Characters)
            if (password.length < 6) {
                alert("Password must be at least 6 characters.");
                return;
            }

            // Show Success Message
            let loginMessage = document.getElementById("loginMessage");
            if (loginMessage) {
                loginMessage.innerText = "Login Successful! Redirecting...";
                loginMessage.style.color = "green";
            }

            loginForm.reset(); // Reset the form
        });
    }
});
